<?php include 'header.php' ?>
<?php include 'menu.php' ?>
<div class="col-md-12">
  <div class="row">
    <div class="col-md-1"></div>
    <div class="col-md-7">
    
  
<button style="text-align: center;" type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Add Recovered Patients</button><br>


<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Recovered Patients</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
<form action="action/a_recovered_patients.php" method="post" class="splash-container">
        <div class="card">
            <div class="card-header">
                <h3 class="mb-1" style="text-align: center; color: green;">Recovered Patients</h3>
                <p style="text-align: center;">Please enter the Recovered Patients details.</p>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <input class="form-control form-control-lg" type="number" name="Patients_ID" placeholder="Enter Patients ID" autocomplete="off" required>
                </div>
				
				
				<label for="">Enter Recovered Date</label><br>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="date" name="Recovered_date"autocomplete="off" required>
                </div>

                <div class="form-group">
                    <textarea style="padding: 10px; border-color: #bdd0ef;" placeholder="Any comments" name="Comments" id="" cols="38" rows="2" required></textarea>
                </div>
               
                <div class="form-group pt-2">
                    <button type="submit" class="btn btn-primary">Submit</button>&nbsp;<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </form>
    </div>
  </div>
</div>
</div>
</div>

<div class="col-md-4">
   <button style="text-align: center;" type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal2">
  Search Recovered Patients Information</button><br>


<div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Search Information</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
            <form action="a_search_recovered_patients.php" method="post">
    <div class="card">
        <div class="card-body">
             <div class="form-group">
                    <input class="form-control form-control-lg" type="number" name="r_search" placeholder="Enter Patients_ID" autocomplete="off" required>
                </div>
            <div class="form-group pt-2">
                    <button type="submit" class="btn btn-primary">Submit</button>&nbsp;<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </form>
    </div>
  </div>
</div>
</div>
</div>

</div>
</div>

<form action="action/a_recovered_patients.php" method="post" class="splash-container">
        <div class="card">
            <div class="card-header">
                <h3 class="mb-1" style="text-align: center; color: green;">Recovered Patients</h3>
                <p style="text-align: center;">Please enter the Recovered Patients details.</p>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <input class="form-control form-control-lg" type="number" name="Patients_ID" placeholder="Enter Patients ID" autocomplete="off" required>
                </div>
                <label for="">Enter Recovered Date</label><br>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="date" name="Recovered_date"autocomplete="off" required>
                </div>

				
				
				<div class="form-group">
                    <textarea style="padding: 10px; border-color: #bdd0ef;" placeholder="Any Comments" name="Comments" id="" cols="38" rows="2" required></textarea>
                </div>
               <div class="form-group pt-2">
                    <button type="submit" class="btn btn-primary">Submit</button>&nbsp;<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </form>

<?php include 'footer1.php' ?>
<?php include 'footer2.php' ?>