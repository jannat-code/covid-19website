<!-- ============================================================== -->
        <!-- left sidebar -->
        <!-- ============================================================== -->
        <div class="nav-left-sidebar sidebar-dark">
            <div class="menu-list">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav flex-column">
                            <li class="nav-divider">
                                <a style="font-size: 20px; color: yellow" href="index.php">Dashboard</a>
                            </li>
                            <li class="nav-item " style="background-color: red !important;">
                                <a class="nav-link active" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-1" aria-controls="submenu-1"><i class="fa fa-fw fa-user-circle"></i>Manage Patients <span class="badge badge-success">6</span></a>
                                <div id="submenu-1" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                       
                                        <li class="nav-item">
                                            <a class="nav-link" href="patients.php">Add Patients Individual</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="recovered_patients.php">Recovered Patients Individual</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="medical_team.php">Medical Team Information</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="Quarantine.php">Quarantine System Information</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="Check_point.php">Check-point System</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link active" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-2" aria-controls="submenu-2"><i class="fas fa-medkit"></i>Support System <span class="badge badge-success">6</span></a>
                                <div id="submenu-2" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                       
                                        <li class="nav-item">
                                            <a class="nav-link" href="team.php">Add Support Team</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="imteam.php">Add Support Team Individual Information</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="team-task.php">Assign Tasks</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link active" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-3" aria-controls="submenu-3"><i class="fas fa-tasks"></i>Activity Management <span class="badge badge-success">6</span></a>
                                <div id="submenu-3" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                       
                                        <li class="nav-item">
                                            <a class="nav-link" href="Awareness_Program.php">Covid-19 Awareness Program </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="Research.php">Research & Expert Team</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="NCS.php">Neighboring Country Situation</a>
                                        </li>
										 <li class="nav-item">
                                            <a class="nav-link" href="Press_Note.php">Covid-19 Press Note</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                            <a class="nav-link active" href="donor.php" ><i class="fas fa-dollar-sign"></i>&nbsp;&nbsp;Donors <span class="badge badge-success">6</span></a>
                            </li>
                           
                            <li class="nav-item ">
                                <a class="nav-link active" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-4" aria-controls="submenu-4"><i class="fas fa-crop"></i>Expenses <span class="badge badge-success">6</span></a>
                                <div id="submenu-4" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                       
                                        <li class="nav-item">
                                            <a class="nav-link" href="expense.php">Expense Manager</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="aid.php">Aid Manager</a>
                                        </li>
                                   
                                    </ul>
                                </div>
                            </li>
                           
                            <li class="nav-item">
                                            <a class="nav-link active" href="emergency.php" ><i class="fas fa-question-circle"></i>Emergency Response <span class="badge badge-success">6</span></a>
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link active" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-5" aria-controls="submenu-5"><i class="fas fa-users"></i>Users <span class="badge badge-success">6</span></a>
                                <div id="submenu-5" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="users.php">Admin</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="users.php">Representatives</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                            <a class="nav-link active" href="#" ><i class="fas fa-cogs"></i>Settings <span class="badge badge-success">6</span></a>
                            </li>
                            
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end left sidebar -->
        <!-- ============================================================== -->

                <!-- ============================================================== -->
        <!-- wrapper  -->
        <!-- ============================================================== -->
        <div class="dashboard-wrapper">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content ">
        