<?php include 'db.php' ?>
<?php 
$sql = "SELECT * FROM donor";
$result = $link->query($sql);
?>
<?php include 'header.php' ?>
<?php include 'menu.php' ?>
<div>
<form action="action/a_donor.php" method="POST" class="splash-container">
        <div class="card">
            <div class="card-header">
                <h3 class="mb-1" style="text-align: center; color: green;">Donation Management</h3>
                <p style="text-align: center;">Please enter the information of a Donor</p>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="doname" placeholder="Enter Donor's Name" autocomplete="off" required>
                </div>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="number" name="donumber" required="" placeholder="Enter Donor's Contact Number" autocomplete="off" required>
                </div>
                <div class="form-group">
					  <label for="sel1">Select Your Gender</label>
						  <select class="form-control" name="dogender" id="sel1">
						    <option>Male</option>
						    <option>Female</option>
						  </select>
				</div>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="dooccupation" placeholder="Enter Donor's Occupation" autocomplete="off" required>
                </div>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="email" name="doemail" placeholder="Enter Donor's Email" autocomplete="off" required>
                </div>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="number" name="doamount" required="" placeholder="Amount of Donation($)" autocomplete="off" required>
                </div>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="date" name="dodate" required="" placeholder="Date of Donation" autocomplete="off" required>
                </div>
                <div class="form-group">
					  <label for="sel1">Select Your Country</label>
						  <select class="form-control" name="docountry" id="sel1">
						    <option>USA</option>
						    <option>UK</option>
						    <option>France</option>
						    <option>China</option>
						    <option>Bangladesh</option>
						    <option>India</option>
						  </select>
				</div>
                <div class="form-group">
                    <textarea style="padding: 10px; border-color: #bdd0ef;" placeholder="Address of Donor" name="doaddress" id="" cols="38" rows="2" required></textarea>
                </div>
                <div class="form-group pt-2">
                    <button class="btn btn-block btn-primary" type="submit">Submit Donor Information</button>
                </div>
        </div>
    </form>
</div>


<div class="card">
<div class="card-body">
<div>
    <h2 style="margin-top: 5px; margin-left: 370px;">List of Donors</h2>
</div>
<br><div>
            <?php 
                if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<div class='ta'><table class='table custom-table'><tr>"."<td>".$row["DONOR_NAME"]."</td> "."<td>". $row["DONOR_COUNTRY"]."</td>"."<td>". $row["DONATION_AMOUNT"]."</td>"."<td>". $row["DONOR_NUMBER"]."</td>"."<br>"."</tr></table></div>";
    } 
} else {
    echo "0 results";
}
$link->close();
             ?>
             <br><br><br>
    </div></div></div>
<?php include 'footer1.php' ?>
<?php include 'footer2.php' ?>