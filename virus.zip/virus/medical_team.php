<?php include 'db.php' ?>
<?php 
$sql = "SELECT * FROM medical_team";
$result = $link->query($sql);
 ?>
<?php include 'header.php' ?>
<?php include 'menu.php' ?>

<div class="col-md-12">
  <div class="row">
    <div class="col-md-1"></div>
    <div class="col-md-7">


<button style="text-align: center;" type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Add Medical Team</button><br>


<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Medical Team</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

            <form action="action/a_medical_team.php" method="post" class="splash-container">
        <div class="card">
            <div class="card-header">
                <h3 class="mb-1" style="text-align: center; color: green;">Medical Team</h3>
                <p style="text-align: center;">Please enter the medical team information.</p>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="mname"
                    placeholder="Enter Team Name" autocomplete="off" required>
                </div>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="pname"
                    placeholder="Enter Treating Patient Name" autocomplete="off" required>
                </div>
                <div class="form-group">
                   <select style="width: 305px; height: 45px;" name="location" id="">
                		<option value="Dhaka" name="location">Dhaka</option>
                		<option value="Jamalpur" name="location">Jamalpur</option>
                		<option value="Rangpur" name="location">Rangpur</option>
                		<option value="Tangail" name="location">Tangail</option>
						<option value="Noakhali" name="location">Noakhali</option>
                		<option value="Cox's Bazar" name="location">Cox's Bazar</option>
                		<option value="Chadpur" name="location">Chadpur</option>
                		<option value="Madaripur" name="location">Madaripur</option>
                	</select>
                </div>
                <div class="form-group">
                    <textarea style="padding: 10px; border-color: #bdd0ef;" placeholder="Enter Situation reports" name="reports" id="" cols="38" rows="2" required></textarea>
                </div>
                <div class="form-group pt-2">
                    <button type="submit" class="btn btn-primary">Save changes</button><button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </form>
    
    </div>
  </div>
</div>

</div>
</div>
<div class="col-md-4">
            <button style="text-align: center;" type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal2">
  Search Individual Medical Team Information</button><br>


<div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content" style="background-color: lightsalmon ;">
      <div class="modal-header" >
        <h5 class="modal-title" id="exampleModalLabel">Search Information</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
            <form action="a_search_medical_team.php" method="post">
    <div class="card">
        <div class="card-body">
             <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="r_search" placeholder="Enter Team_ID " autocomplete="off" required>
                </div>
            <div class="form-group pt-2">
                    <button type="submit" class="btn btn-primary">Save changes</button>&nbsp;<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </form>
    </div>
  </div>
</div>
</div>
        </div>










    <br><div class="card">
        <div class="card-body">
            <div class="row">
            	<?php 
            	echo "<div class='ta'><table class='table custom-table'>"."<tr>"."<h2>All  Medical Team Information</h2>"."</tr>"."</table></div>" ?>
            <?php 
                if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<div class='ta'><table class='table custom-table'>"."<tr>"."<td>".$row["Team_Name"]."</td> "."<td>". $row["Treating_Patient_Name"]."</td>"."<td>". $row["Location"]."</td>"."<td>". $row["reports"]."</td>"."<br>"."</tr>"."</table></div>";
    } 
} else {
    echo "0 results";
}
$link->close();
             ?>
    </div>
        </div>
    </div>

<?php include 'footer1.php' ?>
<?php include 'footer2.php' ?>