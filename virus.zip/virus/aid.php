<?php include 'db.php' ?>
<?php 
$sql = "SELECT * FROM aid";
$result = $link->query($sql);
?>
<?php include 'header.php' ?>
<?php include 'menu.php' ?>

<button style="text-align: center;" type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Add Aid</button><br>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Expense</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
<form action="action/a_aid.php" method="post" class="splash-container">
        <div class="card">
            <div class="card-header">
                <h3 class="mb-1" style="text-align: center; color: green;">Aid Manager</h3>
                <p style="text-align: center;">Please enter the details</p>
            </div>
           <div class="form-group">
                   <select style="width: 305px; height: 45px;" name="aid_type" id="">
                		<option value="salary" name="aid_type">salary</option>
                		<option value="transport" name="aid_type">transport</option>
                		<option value="food" name="aid_type">food</option>
						<option value="clothes" name="aid_type">clothes</option>
						<option value="Shelter" name="aid_type">Shelter</option>
                		</select>
                </div>
                     <div class="form-group">
                    <input class="form-control form-control-lg" type="number" name="amount" placeholder="Amount" autocomplete="off" required>
                </div>
               
                <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="details" placeholder="Provider Details" autocomplete="off" required>
                </div>
              <div class="form-group">
                    <input class="form-control form-control-lg" type="date" name="date"autocomplete="off" required>
                </div>
                  <div class="form-group">
                    <input class="form-control form-control-lg" type="number" name="total_aid" placeholder="Total Aid" autocomplete="off" required>
                </div>
                
                <div class="form-group pt-2">
                    <button type="submit" class="btn btn-primary">Submit</button>&nbsp;<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </form>
    </div>
  </div>
</div>
</div>


<div class="card">
<div class="card-body">
<div>
    <h2 style="margin-top: 5px; margin-left: 370px;">Aid Details</h2>
</div>
<br><div>
            <?php 
                if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<div class='ta'><table class='table custom-table'><tr>"."<td>".$row["Aid_type"]."</td> "."<td>". $row["Amount"]."</td>"."<td>". $row["Details"]."</td>"."<td>". $row["Date"]."<td>". $row["Total_aid"]."</td>"."<br>"."</tr></table></div>";
    } 
} else {
    echo "0 results";
}
$link->close();
             ?>
    </div>
        </div>
    </div>

<?php include 'footer1.php' ?>
<?php include 'footer2.php' ?>