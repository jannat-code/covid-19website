<?php include 'db.php' ?>
<?php 
// create a variable
$r_search=$_POST['r_search'];

//Execute the query

$sql="SELECT * FROM medical_team where Team_ID LIKE'%$r_search%'";
$result = $link->query($sql);


?>
<?php include 'header.php' ?>
<?php include 'menu.php' ?>
<div class="card">
        <div class="card-body">
            <div class="row">
                <div style="margin-left: 200px;">
            <?php 

                if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<div class='ta'><table class='table custom-table'>"
        ."<tr>"."<h2>Teams Individual Information</h2>"."</tr>"
        ."<tr>"."<td>"."Team Name"."</td> "."<td>". $row["Team_Name"]."</td>"."</tr>"
        ."<tr>"."<td>"."Treating Patient Name"."</td> "."<td>". $row["Treating_Patient_Name"]."</td>"."</tr>"
        ."<tr>"."<td>"."Location"."</td> "."<td>". $row["Location"]."</td>"."</tr>"
        ."<tr>"."<td>"."Reports"."</td> "."<td>". $row["reports"]."</td>"."</tr>"."</table></div>";
    } 
} else {
    echo "0 results";
}
$link->close();
             ?>
                 
             </div>
    </div>
        </div>
    </div>

    <?php include 'footer1.php' ?>
<?php include 'footer2.php' ?>