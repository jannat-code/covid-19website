<?php include 'db.php' ?>
<?php 
// create a variable
$r_search=$_POST['r_search'];

//Execute the query

$sql="SELECT * FROM team WHERE 	Team_ID LIKE'%$r_search%'";
$sql2="SELECT * FROM team_task WHERE 	Team_ID LIKE'%$r_search%'";
$result = $link->query($sql);
$result2 = $link->query($sql2);


?>
<?php include 'header.php' ?>
<?php include 'menu.php' ?>
<div class="card">
        <div class="card-body">
            <div class="row">
                <div style="margin-left: 200px;">
            <?php 


                if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<div class='ta'><table class='table custom-table'>"
        ."<tr>"."<h2>Team Individual Information</h2>"."</tr>"
        ."<tr>"."<td>"."Team Type"."</td> "."<td>". $row["team_type"]."</td>"."</tr>"
        ."<tr>"."<td>"."Team Area"."</td> "."<td>". $row["team_area"]."</td>"."</tr>"."</table></div>";
    } 
    while($row = $result2->fetch_assoc()) {
        echo "<div class='ta'><table class='table custom-table'>"
        ."<tr>"."<td>"."Team Name"."</td> "."<td>". $row["Team_name"]."</td>"."</tr>"
        ."<tr>"."<td>"."Team Task"."</td> "."<td>". $row["Team_Task"]."</td>"."</tr>";
    } 
} 

            
$link->close();
             ?>
                 
             </div>
    </div>
        </div>
    </div>

<?php include 'special_footer.php' ?>
<?php include 'footer2.php' ?>