<?php include 'db.php' ?>
<?php 
$sql = "SELECT * FROM press_note";
$result = $link->query($sql);
?>
<?php include 'header.php' ?>
<?php include 'menu.php' ?>
<div>
<form action="action/a_press_note.php" method="POST" class="splash-container">
        <div class="card">
            <div class="card-header">
                <h3 class="mb-1" style="text-align: center; color: green;">Press Note</h3>
                <p style="text-align: center;">Please enter the details</p>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <input class="form-control form-control-lg" type="number" name="pr_ID" placeholder="Press ID" autocomplete="off" required>
                </div>
                 <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="name" placeholder=" Press name" autocomplete="off" required>
                </div>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="pr_details" required="" placeholder="Press Note Details" autocomplete="off" required>
                </div>
				 
                
                <div class="form-group pt-2">
                    <button class="btn btn-block btn-primary" type="submit">Submit</button>
                </div>
        </div>
    </form></div>

<div class="card">
<div class="card-body">
<div>
    <h2 style="margin-top: 5px; margin-left: 370px;">Press Note Details</h2>
</div>
<br><div>
            <?php 
                if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<div class='ta'><table class='table custom-table'><tr>"."<td>".$row["Press_ID"]."</td> "."<td>". $row["press_name"]."</td>"."<td>". $row["Press_Details"]."</td>"."<br>"."</tr></table></div>";
    } 
} else {
    echo "0 results";
}
$link->close();
             ?>
    </div></div></div>

<?php include 'footer1.php' ?>
<?php include 'footer2.php' ?>