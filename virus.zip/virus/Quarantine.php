<?php include 'db.php' ?>
<?php 
$sql="SELECT * FROM quarantine";
$result = $link->query($sql);
 ?>


<?php include 'header.php' ?>
<?php include 'menu.php' ?>

<form action="action/a_quarantine.php" method="post" class="splash-container">
        <div class="card">
            <div class="card-header">
                <h3 class="mb-1" style="text-align: center; color: green;">Quarantine System Data Entry</h3>
                <p style="text-align: center;">Please enter the details.</p>
            </div>
            <div class="card-body">
            	<label for="">Enter the needs:</label><br>
                <div class="form-group">
                     <select style="width: 305px; height: 45px;" name="needs" id="">
                		<option value="Virus Kits" name="needs">Virus Kits</option>
                		<option value="Nebulizer" name="needs">Nebulizer</option>
                		<option value="Masks" name="needs">Masks</option>
                		<option value="Gowns" name="needs">Gowns</option>
						<option value="Gloves" name="needs">Gloves</option>
                		<option value="Caps" name="needs">Capes</option>
                		<option value="Ventilators" name="needs">Ventilators</option>
                		<option value="Sanitizer" name="needs">Sanitizer</option>
                	</select>
                </div>
                <div class="form-group">
                   <textarea style="padding: 8px; border-color: #bdd0ef;" placeholder="Enter the Facilities details:" name="facilities" id="" cols="33" rows="1" required></textarea>
                </div>
				 <div class="form-group">
                   <select style="width: 305px; height: 45px;" name="location" id="">
                		<option value="Dhaka" name="location">Dhaka</option>
                		<option value="Jamalpur" name="location">Jamalpur</option>
                		<option value="Rangpur" name="location">Rangpur</option>
                		<option value="Tangail" name="location">Tangail</option>
						<option value="Noakhali" name="location">Noakhali</option>
                		<option value="Cox's Bazar" name="location">Cox's Bazar</option>
                		<option value="Chadpur" name="location">Chadpur</option>
                		<option value="Madaripur" name="location">Madaripur</option>
                	</select>
                </div>
				<div class="form-group">
                   <textarea style="padding: 8px; border-color: #bdd0ef;" placeholder="Enter the working team:" name="working_team" id="" cols="33" rows="1" required></textarea>
                </div>
				
                
                <div class="form-group pt-2">
                    <button class="btn btn-block btn-primary" type="submit">Submit</button>
                </div>
            </div>
        </div>
    </form>
	<br><div class="card">
        <div class="card-body">
            <div class="row">
            	<?php 
            	echo "<div class='ta'><table class='table custom-table'>"."<tr>"."<h2>Quarantine System Information</h2>"."</tr>"."</table></div>" ?>
            <?php 
                if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<div class='ta'><table class='table custom-table'>"."<tr>"
		."<td>".$row["needs"]."</td> "
		."<td>". $row["facilities"]."</td>"
		."<td>". $row["location"]."</td>"
		."<td>". $row["working_team"]."</td>"."<br>"."</tr>"."</table></div>";
    } 
} else {
    echo "0 results";
}
$link->close();
             ?>
    </div>
        </div>
    </div>


<?php include 'footer1.php' ?>
<?php include 'footer2.php' ?>