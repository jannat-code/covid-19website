<?php include 'header.php' ?>
<?php include 'menu.php' ?>

                    <!-- ============================================================== -->
                    <!-- pageheader  -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <h2 class="pageheader-title">Virus Information System </h2>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end pageheader  -->
                    <!-- ============================================================== -->
                    <div class="ecommerce-widget">

                        <div class="row">
                            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="text-muted" color="green">Coronavirus Cases:
</h5>
                                        <div class="metric-value d-inline-block">
                                            <h1 class="mb-1">20,592,470</h1>
                                        </div>
                                       
                                    </div>
                                    <div id="sparkline-revenue"></div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="text-muted">Deaths:</h5>
                                        <div class="metric-value d-inline-block">
                                            <h1 class="mb-1">747,224</h1>
                                        </div>
                                        </div>
                                    <div id="sparkline-revenue2"></div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="text-muted">Recovered:</h5>
                                        <div class="metric-value d-inline-block">
                                            <h1 class="mb-1">13,503,836</h1>
                                        </div>
                                    
                                    </div>
                                    <div id="sparkline-revenue3"></div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="text-muted">Crisis Situation Level</h5>
                                        <div class="metric-value d-inline-block">
                                            <h1 class="mb-1">Alarming</h1>
                                        </div>
                                        <div class="metric-label d-inline-block float-right text-secondary font-weight-bold">
                                            <span>HIGH</span>
                                        </div>
                                    </div>
                                    <div id="sparkline-revenue4"></div>
                                </div>
                            </div>
                        </div>
                        

<?php include 'footer1.php' ?>
<?php include 'footer2.php' ?>