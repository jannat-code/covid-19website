<?php include 'db.php' ?>
<?php 
$sql = "SELECT * FROM ncs";
$result = $link->query($sql);
?>
<?php include 'header.php' ?>
<?php include 'menu.php' ?>
<div>

<form action="action/a_ncs.php" method="POST" class="splash-container">
        <div class="card">
            <div class="card-header">
                <h3 class="mb-1" style="text-align: center; color: green;">Others Country Situation</h3>
                <p style="text-align: center;">Please enter the details</p>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="c_name" placeholder="Country Name" autocomplete="off" required>
                </div>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="number" name="no_affected" required="" placeholder="Number of affected people" autocomplete="off" required>
                </div>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="number" name="no_death" required="" placeholder="Number of Death" autocomplete="off" required>
                </div>
                <div class="form-group">
                    <textarea style="padding: 10px; border-color: #bdd0ef;" placeholder="Current Situation" name="c_situation" id="" cols="38" rows="3" required></textarea>
                </div>
                <div class="form-group pt-2">
                    <button class="btn btn-block btn-primary" type="submit">Submit</button>
                </div>
        </div>
    </form>

</div>

<div class="card">
<div class="card-body">
<div>
    <h2 style="margin-top: 5px; margin-left: 370px;">Others Country Situation Details</h2>
</div>
<br><div>
            <?php 
                if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<div class='ta'><table class='table custom-table'><tr>"."<td>".$row["Country_Name"]."</td> "."<td>". $row["No_of_affected_people"]."</td>"."<td>". $row["No_of_Death"]."</td>"."<td>". $row["Current_Situation"]."<br>"."</tr></table></div>";
    } 
} else {
    echo "0 results";
}
$link->close();
             ?>
    </div></div></div>

<?php include 'footer1.php' ?>
<?php include 'footer2.php' ?>




































