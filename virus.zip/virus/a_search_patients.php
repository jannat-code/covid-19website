<?php include 'db.php' ?>
<?php 
// create a variable
$r_search=$_POST['r_search'];

//Execute the query

$sql="SELECT * FROM patients_individual where Patients_ID LIKE'%$r_search%'";
$result = $link->query($sql);


?>
<?php include 'header.php' ?>
<?php include 'menu.php' ?>
<div class="card">
        <div class="card-body">
            <div class="row">
                <div style="margin-left: 200px;">
            <?php 

                if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<div class='ta'><table class='table custom-table'>"
        ."<tr>"."<h2>Patients Individual Information</h2>"."</tr>"
        ."<tr>"."<td>"."Patients Name"."</td> "."<td>". $row["Patients_Name"]."</td>"."</tr>"
        ."<tr>"."<td>"."Father Name"."</td> "."<td>". $row["Father_Name"]."</td>"."</tr>"
        ."<tr>"."<td>"."Mother Name"."</td> "."<td>". $row["Mother_Name"]."</td>"."</tr>"
        ."<tr>"."<td>"."Date of Birth"."</td> "."<td>". $row["Date_of_Birth"]."</td>"."</tr>"
        ."<tr>"."<td>"."Address"."</td> "."<td>". $row["Address"]."</td>"."</tr>"
        ."<tr>"."<td>"."Gender"."</td> "."<td>". $row["Gender"]."</td>"."</tr>"
        ."<tr>"."<td>"."Marital Status"."</td> "."<td>". $row["Marital_Status"]."</td>"."</tr>"
        ."<tr>"."<td>"."Blood Group"."</td> "."<td>". $row["Blood_Group"]."</td>"."</tr>"
        ."<tr>"."<td>"."Symptoms"."</td> "."<td>". $row["Symptoms"]."</td>"."</tr>"
        ."<tr>"."<td>"."Migration country"."</td> "."<td>". $row["Migration"]."</td>"."</tr>"
		."<tr>"."<td>"."Date of Migration "."</td> "."<td>". $row["Migration_Date"]."</td>"."</tr>"
        ."<tr>"."<td>"."Quantine Migration date "."</td> "."<td>". $row["Qunt_Migration_Date"]."</td>"."</tr>"."</table></div>";
    } 
} else {
    echo "0 results";
}
$link->close();
             ?>
                 
             </div>
    </div>
        </div>
    </div>

    <?php include 'footer1.php' ?>
<?php include 'footer2.php' ?>