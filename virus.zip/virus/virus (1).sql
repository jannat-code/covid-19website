-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 09, 2020 at 02:15 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `virus`
--

-- --------------------------------------------------------

--
-- Table structure for table `aid`
--

CREATE TABLE `aid` (
  `Aid_Id` int(10) NOT NULL,
  `Aid_type` text NOT NULL,
  `Amount` int(100) NOT NULL,
  `Details` varchar(30) NOT NULL,
  `Date` date NOT NULL,
  `Total_aid` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aid`
--

INSERT INTO `aid` (`Aid_Id`, `Aid_type`, `Amount`, `Details`, `Date`, `Total_aid`) VALUES
(11, 'salary', 100000, 'China,India', '2020-09-04', 12000000),
(12, 'food', 660000, 'UK', '2020-05-05', 660000),
(13, 'clothes', 770000, 'Australia', '2020-04-04', 700000),
(14, 'transport', 230000, 'USA', '2020-02-04', 230000),
(15, 'Shelter', 800000, 'Japan', '2020-09-06', 800000),
(16, 'salary', 550000, 'China', '2020-06-05', 550000);

-- --------------------------------------------------------

--
-- Table structure for table `awareness`
--

CREATE TABLE `awareness` (
  `Program_ID` int(10) NOT NULL,
  `Program_Name` varchar(100) NOT NULL,
  `Duration` varchar(200) NOT NULL,
  `Program_Details` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `awareness`
--

INSERT INTO `awareness` (`Program_ID`, `Program_Name`, `Duration`, `Program_Details`) VALUES
(20014, 'GetRidCorona', '1 month', 'no'),
(20015, 'Covid-19 & Domestic Violence', '3 month', 'Supervision and fixed violence'),
(20017, 'Secure funding and supplies', '2 month', 'fixed finding and supplies for all affected people'),
(20018, 'Organize Health Facilities', '3 month', 'Monitoring and fixed health facilities for affected people'),
(20019, 'Ensure Infection Control', '15 days', 'Ensure and supervision of all infection'),
(20020, 'Ensure Full Treatment', '3 month', 'Fixed monitoring and ensure full treatment for affected people'),
(20021, 'Add Volunteer', 'untill situation control', 'Add volunteer in the cities where are affected peoples'),
(20045, '20045', '3 month', 'safty of people');

-- --------------------------------------------------------

--
-- Table structure for table `check_point`
--

CREATE TABLE `check_point` (
  `check_point_id` int(10) NOT NULL,
  `Area_type` text NOT NULL,
  `Check_point_name` varchar(100) NOT NULL,
  `Facilities` text NOT NULL,
  `Team_ID` int(100) NOT NULL,
  `People_detected` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `check_point`
--

INSERT INTO `check_point` (`check_point_id`, `Area_type`, `Check_point_name`, `Facilities`, `Team_ID`, `People_detected`) VALUES
(1, 'Airport', 'point-1', 'Up To Date', 1, 10),
(2, 'Airport', 'point-2', 'Virus detection kit missing', 2, 22),
(3, 'Land port', 'port-1', 'Up To Date', 33, 22);

-- --------------------------------------------------------

--
-- Table structure for table `donor`
--

CREATE TABLE `donor` (
  `DONOR_ID` int(10) NOT NULL,
  `DONOR_NAME` text NOT NULL,
  `DONOR_NUMBER` int(11) NOT NULL,
  `DONOR_GENDER` text NOT NULL,
  `DONOR_OCCUPAATAION` text NOT NULL,
  `DONOR_EMAIL` varchar(30) NOT NULL,
  `DONATION_AMOUNT` int(10) NOT NULL,
  `DONOR_DATE` date NOT NULL,
  `DONOR_COUNTRY` text NOT NULL,
  `DONOR_ADDRESS` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donor`
--

INSERT INTO `donor` (`DONOR_ID`, `DONOR_NAME`, `DONOR_NUMBER`, `DONOR_GENDER`, `DONOR_OCCUPAATAION`, `DONOR_EMAIL`, `DONATION_AMOUNT`, `DONOR_DATE`, `DONOR_COUNTRY`, `DONOR_ADDRESS`) VALUES
(1, 'john', 985678399, 'Male', 'Business', 'bkbidhan12@gmail.com', 4000, '2020-03-05', 'USA', 'USA'),
(2, 'Talha', 1798568458, 'Male', 'Service', 'himel@gmail.com', 1000, '2020-03-03', 'Bangladesh', 'Dhaka,Bangladesh'),
(3, 'Sawda', 1798568458, 'Female', 'Service', 'sawda@gmail.com', 1000, '2020-04-04', 'Bangladesh', 'Jamalpur,Bangladesh'),
(4, 'nadia', 17393939, 'female', 'job', 'nadia@gmail.com', 46, '2020-06-05', 'USA', 'USA'),
(5, 'jannat', 9788686, 'Female', 'student', 'jannat@gmail.com', 34, '2020-03-05', 'Bangladesh', 'Noakhali,Dhaka'),
(6, 'jannat', 1365869, 'Female', 'doctor', 'jannat@gmail.com', 5, '2020-06-04', 'Bangladesh', 'bangladesh');

-- --------------------------------------------------------

--
-- Table structure for table `emergency`
--

CREATE TABLE `emergency` (
  `EMERGENCY_ID` int(10) NOT NULL,
  `PROBLEM` varchar(100) NOT NULL,
  `SOLUTION` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emergency`
--

INSERT INTO `emergency` (`EMERGENCY_ID`, `PROBLEM`, `SOLUTION`) VALUES
(1, ' How to Identify Covid-19?', 'Test Report cannot be identified throughout.'),
(2, '  Covid-19 Symptoms', 'Fever, Dry Cough, Sore throat, Headache, Difficult breathing or shortness of breath, chest pain or pressure.\r\n'),
(3, '  Medications', ' Antiviral or retroviral medications, breathing support, such as mechanical ventilation, steroids to reduce lung swelling, blood plasma transfusions'),
(4, '  Covid-19 Symptoms', 'Fever, Dry Cough, Sore throat, Headache, Difficult breathing or shortness of breath, chest pain or pressure.\r\n'),
(5, ' Medications', 'Antiviral or retroviral medications, breathing support, such as mechanical ventilation, steroids to reduce lung swelling, blood plasma transfusions.\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `expense`
--

CREATE TABLE `expense` (
  `Expense_ID` int(10) NOT NULL,
  `Expense_Name` varchar(15) NOT NULL,
  `Expense_Amount` int(10) NOT NULL,
  `Expense_Date` date NOT NULL,
  `Expense_Details` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `expense`
--

INSERT INTO `expense` (`Expense_ID`, `Expense_Name`, `Expense_Amount`, `Expense_Date`, `Expense_Details`) VALUES
(11, 'Salary', 100000, '2020-04-03', 'USA'),
(12, 'Transport', 230000, '2020-04-04', 'Bangladesh'),
(13, 'Food', 660000, '2020-04-03', 'Japan'),
(14, 'Clothes', 770000, '2020-05-05', 'USA'),
(15, 'Health Cluster', 330000, '2020-06-06', 'Russia'),
(16, 'Safety Device', 300000, '2020-03-05', 'China'),
(17, 'Fund', 380000, '2020-05-02', 'UK'),
(18, 'Support Staff', 40000, '2020-05-05', 'China');

-- --------------------------------------------------------

--
-- Table structure for table `medical_team`
--

CREATE TABLE `medical_team` (
  `Team_ID` int(11) NOT NULL,
  `Team_Name` varchar(100) NOT NULL,
  `Treating_Patient_Name` text NOT NULL,
  `Location` text NOT NULL,
  `reports` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medical_team`
--

INSERT INTO `medical_team` (`Team_ID`, `Team_Name`, `Treating_Patient_Name`, `Location`, `reports`) VALUES
(1, 'Team-a', 'Pranto Shikder', 'Dhaka', 'high Fever'),
(2, 'jannat', 'Pranto Shikder', 'Dhaka', 'Dry Caugh'),
(3, 'team-alpha', 'Obaydur Kader', 'Dhaka', 'not good'),
(4, 'team-b', 'jobor', 'Dhaka', 'ceitical'),
(5, 'team-c', 'Rawnak Jahan', 'Rangpur', 'critical'),
(6, 'team-alpa', 'saffi', 'Rangpur', 'critical');

-- --------------------------------------------------------

--
-- Table structure for table `ncs`
--

CREATE TABLE `ncs` (
  `ID` int(10) NOT NULL,
  `Country_Name` text NOT NULL,
  `No_of_affected_people` int(255) NOT NULL,
  `No_of_Death` int(255) NOT NULL,
  `Current_Situation` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ncs`
--

INSERT INTO `ncs` (`ID`, `Country_Name`, `No_of_affected_people`, `No_of_Death`, `Current_Situation`) VALUES
(1, 'India', 2360358, 46536, 'alarming'),
(2, 'usa', 5309622, 167789, 'alarming'),
(3, 'Russia', 902701, 15260, 'alarming'),
(4, 'Pakistan', 285921, 2612, 'alarming'),
(5, 'Saudi Arabia', 317486, 3956, 'critical'),
(6, 'Bangladesh', 317528, 4351, 'rising'),
(7, 'Spain', 479554, 29194, 'critical');

-- --------------------------------------------------------

--
-- Table structure for table `patients_individual`
--

CREATE TABLE `patients_individual` (
  `Patients_ID` int(10) NOT NULL,
  `Patients_Name` text NOT NULL,
  `Father_Name` text NOT NULL,
  `Mother_Name` text NOT NULL,
  `Date_of_Birth` date NOT NULL,
  `Address` varchar(150) NOT NULL,
  `Gender` text NOT NULL,
  `Marital_Status` text NOT NULL,
  `Blood_Group` varchar(10) NOT NULL,
  `Symptoms` varchar(100) NOT NULL,
  `Migration` text NOT NULL,
  `Migration_Date` date NOT NULL,
  `Qunt_Migration_Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patients_individual`
--

INSERT INTO `patients_individual` (`Patients_ID`, `Patients_Name`, `Father_Name`, `Mother_Name`, `Date_of_Birth`, `Address`, `Gender`, `Marital_Status`, `Blood_Group`, `Symptoms`, `Migration`, `Migration_Date`, `Qunt_Migration_Date`) VALUES
(1, 'Pranto Shikder', 'Sayed Ali', 'Hena Khanom', '1985-04-09', 'Sherpur', 'Male', 'Married', 'B+', 'Dry Caugh', 'Italy', '2020-03-05', '2020-03-07'),
(2, 'Mohammad Kabir', 'Sadikur Rahman', 'Tazri Sarker', '1980-08-06', 'Kushtia', 'Male', 'Married', 'O+', 'Fever', 'United States', '2020-04-01', '2020-04-05'),
(3, 'Delowar Hossain', 'Mosaddek Hossen', 'Sonia Afroz', '1993-07-05', 'Rangpur', 'Male', 'Unmarried', 'A+', 'Sore throat', 'Brazil', '2020-03-01', '2020-03-03'),
(4, 'Obaydul Kader', 'Mohammad Kader', 'Helena Begum', '2020-11-25', 'Mymensingh', 'Male', 'Married', 'AB+', 'Headache', 'USA', '2020-03-10', '2020-03-12'),
(5, 'Afrose Jahan', 'Farhan Kibria', 'Habibunnahar', '1996-01-01', 'Sylhet', 'Female', 'Married', 'O-', 'Chest Pain', 'Saudi Arabia', '2020-02-12', '2020-03-14'),
(6, 'Rawnak Jahan', 'Shofi Jaman', 'Rita Begum', '1994-07-05', 'Barisal', 'Female', 'Unmarried', 'A+', 'Difficult Breathing', 'India', '2020-04-18', '2020-04-20'),
(7, 'Sumona Rahman', 'Motiar Rahman', 'Momtaj Begum', '1990-09-07', 'Khulna', 'Female', 'Married', 'B-', 'Shortness of breath', 'Russia', '2020-03-11', '2020-03-13'),
(8, 'Zihad Rahman', 'Bulbul Ahmed', 'Salvesila Sawda', '1988-05-01', 'Rajshahi', 'Male', 'Married', 'A-', 'Body pain', 'Qatar', '2020-04-20', '2020-04-22'),
(9, 'Rehana Begum', 'Moazzem Khan', 'Jannatul Ferdous', '1998-08-17', 'Meherpur', 'Female', 'Unmarried', 'B-', 'Dry Caugh', 'Spain', '2020-04-27', '2020-04-30');

-- --------------------------------------------------------

--
-- Table structure for table `press_note`
--

CREATE TABLE `press_note` (
  `Press_ID` int(10) NOT NULL,
  `press_name` varchar(100) NOT NULL,
  `Press_Details` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `press_note`
--

INSERT INTO `press_note` (`Press_ID`, `press_name`, `Press_Details`) VALUES
(1, 'new dhaka', 'new 15 patients infected'),
(45, 'washington dc', 'CDC asks states to prepare to distribute coronavirus vaccine as soon as Nov. 1'),
(56, 'indianexpress', 'Covid-19 vaccine tracker, September 2: Oxford begins stage-3 trials in the US'),
(68, 'The new york time', 'Covid-19 Live Updates: With 1,000 Student Infections, U. of South Carolina Urges Vigilance\r\n'),
(565, 'times of uk', 'new cases have found'),
(5769, 'new times', 'new 15 people died in corona virus'),
(6547, 'prothom alo', '1000 new tests of corona virus');

-- --------------------------------------------------------

--
-- Table structure for table `quarantine`
--

CREATE TABLE `quarantine` (
  `quarantine_ID` int(12) NOT NULL,
  `needs` varchar(20) NOT NULL,
  `facilities` varchar(20) NOT NULL,
  `location` text NOT NULL,
  `working_team` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quarantine`
--

INSERT INTO `quarantine` (`quarantine_ID`, `needs`, `facilities`, `location`, `working_team`) VALUES
(1, 'Virus Kits', 'hospital', 'Dhaka', '20'),
(2, 'Nebulizer', 'All up to date', 'Rangpur', '15'),
(3, 'Gloves', 'All up to date', 'Jamalpur', '30'),
(4, 'Ventilators', 'All up to date', 'Noakhali', '18'),
(5, 'Nebulizer', 'All up to date', 'Sylhet', '16');

-- --------------------------------------------------------

--
-- Table structure for table `recovered_patients`
--

CREATE TABLE `recovered_patients` (
  `Patients_ID` int(100) NOT NULL,
  `Recovered_date` date NOT NULL,
  `Comments` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `recovered_patients`
--

INSERT INTO `recovered_patients` (`Patients_ID`, `Recovered_date`, `Comments`) VALUES
(1, '2020-07-04', 'Take enough rest'),
(2, '2020-05-04', 'no comments'),
(3, '2020-03-05', 'no'),
(4, '2020-06-06', 'avoid social gathering'),
(6, '2020-09-15', 'keep social distance');

-- --------------------------------------------------------

--
-- Table structure for table `research`
--

CREATE TABLE `research` (
  `Research_Team_ID` int(10) NOT NULL,
  `Research_Team_Name` text NOT NULL,
  `Research_Activities` text NOT NULL,
  `Contact_Number` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `research`
--

INSERT INTO `research` (`Research_Team_ID`, `Research_Team_Name`, `Research_Activities`, `Contact_Number`) VALUES
(24, 'tp', 'cure', 7796872),
(34, 'p-5', 'virus', 766587),
(35, 'p-1', 'cure', 25465),
(53, 'p-3', 'medicine', 16789909);

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE `team` (
  `Team_ID` int(100) NOT NULL,
  `team_type` varchar(100) NOT NULL,
  `team_area` text NOT NULL,
  `team_contact` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `team`
--

INSERT INTO `team` (`Team_ID`, `team_type`, `team_area`, `team_contact`) VALUES
(1, 'Volunteer', 'jamalpur', 880177877),
(2, 'First Aid Support', 'tangail', 17897900),
(3, 'Volunteer', 'Coxs Bazar', 1733828567),
(4, 'Security Guards', 'Chittagong', 1876543278),
(5, 'Hospital', 'Rangpur', 1754324567),
(6, 'Hospital', 'dhaka', 880188657),
(7, 'Hospital', 'syhlet', 196868667),
(8, 'Hospital', 'Rangpur', 1745676768),
(9, 'Hospital', 'cox\'s bazar', 9807683);

-- --------------------------------------------------------

--
-- Table structure for table `team_member`
--

CREATE TABLE `team_member` (
  `Member_ID` int(10) NOT NULL,
  `Member_Name` text NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Team_Type` varchar(10) NOT NULL,
  `Contact` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `team_member`
--

INSERT INTO `team_member` (`Member_ID`, `Member_Name`, `Email`, `Team_Type`, `Contact`) VALUES
(1, 'jafrin', 'fs@gmail.com', 'Hospital', 6568080),
(2, 'sawda', 'sawda@gmail.com', 'Hospital', 17979799),
(3, 'jannat', 'jannat@gmail.com', 'Hospital', 179707909),
(4, 'saffi', 'saffi@gmail.com', 'First Aid ', 2147483647),
(5, 'shamim', 'shamim@gmail.com', 'Volunteer', 79689681);

-- --------------------------------------------------------

--
-- Table structure for table `team_task`
--

CREATE TABLE `team_task` (
  `Team_ID` int(10) NOT NULL,
  `Team_name` varchar(15) NOT NULL,
  `Team_Task` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `team_task`
--

INSERT INTO `team_task` (`Team_ID`, `Team_name`, `Team_Task`) VALUES
(1, 'Vol-1', 'give first aid'),
(2, 'Hos-2', 'supply equipment'),
(3, 'Hos-1', 'treat patients'),
(4, 'FAid-1', 'give first aid'),
(5, 'SG-2', 'give security to entry point\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`) VALUES
(1, 'jannat', '$2y$10$tccsXaiSs2p/Yh603CjktuWJLLfwULDZsmtSG83famQCKUViMIw1y', '2020-08-09 16:03:13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aid`
--
ALTER TABLE `aid`
  ADD PRIMARY KEY (`Aid_Id`);

--
-- Indexes for table `awareness`
--
ALTER TABLE `awareness`
  ADD PRIMARY KEY (`Program_ID`);

--
-- Indexes for table `check_point`
--
ALTER TABLE `check_point`
  ADD PRIMARY KEY (`check_point_id`);

--
-- Indexes for table `donor`
--
ALTER TABLE `donor`
  ADD PRIMARY KEY (`DONOR_ID`);

--
-- Indexes for table `emergency`
--
ALTER TABLE `emergency`
  ADD PRIMARY KEY (`EMERGENCY_ID`);

--
-- Indexes for table `expense`
--
ALTER TABLE `expense`
  ADD PRIMARY KEY (`Expense_ID`);

--
-- Indexes for table `medical_team`
--
ALTER TABLE `medical_team`
  ADD PRIMARY KEY (`Team_ID`);

--
-- Indexes for table `ncs`
--
ALTER TABLE `ncs`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `patients_individual`
--
ALTER TABLE `patients_individual`
  ADD PRIMARY KEY (`Patients_ID`);

--
-- Indexes for table `press_note`
--
ALTER TABLE `press_note`
  ADD PRIMARY KEY (`Press_ID`);

--
-- Indexes for table `quarantine`
--
ALTER TABLE `quarantine`
  ADD PRIMARY KEY (`quarantine_ID`);

--
-- Indexes for table `recovered_patients`
--
ALTER TABLE `recovered_patients`
  ADD PRIMARY KEY (`Patients_ID`);

--
-- Indexes for table `research`
--
ALTER TABLE `research`
  ADD PRIMARY KEY (`Research_Team_ID`);

--
-- Indexes for table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`Team_ID`);

--
-- Indexes for table `team_member`
--
ALTER TABLE `team_member`
  ADD PRIMARY KEY (`Member_ID`);

--
-- Indexes for table `team_task`
--
ALTER TABLE `team_task`
  ADD PRIMARY KEY (`Team_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aid`
--
ALTER TABLE `aid`
  MODIFY `Aid_Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `check_point`
--
ALTER TABLE `check_point`
  MODIFY `check_point_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `donor`
--
ALTER TABLE `donor`
  MODIFY `DONOR_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `emergency`
--
ALTER TABLE `emergency`
  MODIFY `EMERGENCY_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `expense`
--
ALTER TABLE `expense`
  MODIFY `Expense_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `medical_team`
--
ALTER TABLE `medical_team`
  MODIFY `Team_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `ncs`
--
ALTER TABLE `ncs`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `patients_individual`
--
ALTER TABLE `patients_individual`
  MODIFY `Patients_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `quarantine`
--
ALTER TABLE `quarantine`
  MODIFY `quarantine_ID` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `recovered_patients`
--
ALTER TABLE `recovered_patients`
  MODIFY `Patients_ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `team`
--
ALTER TABLE `team`
  MODIFY `Team_ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `team_member`
--
ALTER TABLE `team_member`
  MODIFY `Member_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `team_task`
--
ALTER TABLE `team_task`
  MODIFY `Team_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
