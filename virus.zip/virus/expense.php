<?php include 'db.php' ?>
<?php 
$sql = "SELECT * FROM expense";
$result = $link->query($sql);
?>
<?php include 'header.php' ?>
<?php include 'menu.php' ?>

<button style="text-align: center;" type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Add Expense</button><br>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Expense Manager</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
<form action="action/a_expense.php" method="post" class="splash-container">
        <div class="card">
            <div class="card-header">
                <h3 class="mb-1" style="text-align: center; color: green;">Expense Manager</h3>
                <p style="text-align: center;">Please enter the expense details</p>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="exname" placeholder="Expense Name" autocomplete="off" required>
                </div>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="number" name="examount" placeholder="Amount of Expense($)" autocomplete="off" required>
                </div>
                <label for="">Date of Expense</label><br>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="date" name="exdate"autocomplete="off" required>
                </div>
                <div class="form-group">
                    <textarea style="padding: 10px; border-color: #bdd0ef;" placeholder="Details of Expense" name="exdetails" id="" cols="38" rows="3" required></textarea>
                </div>
                <div class="form-group pt-2">
                    <button type="submit" class="btn btn-primary">Save changes</button>&nbsp;<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </form>
    </div>
  </div>
</div>
</div>


<div class="card">
<div class="card-body">
<div>
    <h2 style="margin-top: 5px; margin-left: 370px;">Expense Details</h2>
</div>
<br><div>
            <?php 
                if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<div class='ta'><table class='table custom-table'><tr>"."<td>".$row["Expense_Name"]."</td> "."<td>". $row["Expense_Amount"]."</td>"."<td>". $row["Expense_Date"]."</td>"."<td>". $row["Expense_Details"]."<br>"."</tr></table></div>";
    } 
} else {
    echo "0 results";
}
$link->close();
             ?>
    </div>
        </div>
    </div>

<?php include 'footer1.php' ?>
<?php include 'footer2.php' ?>