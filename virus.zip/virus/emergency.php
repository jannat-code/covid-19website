<?php include 'header.php' ?>
<?php include 'menu.php' ?>

<button style="text-align: center;" type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Add Emergency Response</button><br>


<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Emergency Response</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

            <form action="action/a_emergency.php" method="POST" class="splash-container">
        <div class="card">
            <div class="card-header">
                <h3 class="mb-1" style="text-align: center; color: green;">Emerency Response</h3>
                <p style="text-align: center;">Please add the response of emergency  situation</p>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <textarea style="padding: 10px; border-color: #bdd0ef;" placeholder="Name of the Problem" name="PROBLEM" id="" cols="38" rows="2" required></textarea>
                </div>
                <div class="form-group">
                    <textarea style="padding: 10px; border-color: #bdd0ef;" placeholder="How to solve it?" name="SOLUTION" id="" cols="38" rows="5" required></textarea>
                </div>
                <div class="form-group pt-2">
                    <button type="submit" class="btn btn-primary">Save changes</button>&nbsp;<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </form>
    
    </div>
  </div>
</div>
</div>






<br>

    <div>
        <p>
		<button style="width: 200px;" class="btn btn-primary" type="button" data-toggle="collapse" data-target="#collapse1" aria-expanded="false" aria-controls="collapseExample">
            How to Identify Covid-19?
          </button>
          <a class="btn btn-primary" data-toggle="collapse" href="#collapse1" role="button" aria-expanded="false" aria-controls="collapseExample">
            See Details
          </a>
          
        </p>
        <div class="collapse" id="collapse1">
          <div class="card card-body">
		  Test Report cannot be identified throughout.
		     </div>
        </div>
    </div>

     <div>
        <p>
		 <button style="width: 200px;" class="btn btn-primary" type="button" data-toggle="collapse" data-target="#collapse2" aria-expanded="false" aria-controls="collapseExample">
            Covid-19 Symptoms
          </button>
          <a class="btn btn-primary" data-toggle="collapse" href="#collapse2" role="button" aria-expanded="false" aria-controls="collapseExample">
            See Details
          </a>
         
        </p>
        <div class="collapse" id="collapse2">
          <div class="card card-body">
             <p> People with COVID-19 have had a wide range of symptoms reported – ranging from mild symptoms to severe illness. These symptoms may appear 2-14 days after exposure to the virus:

<li>Fever</li>
<li>Cough</li>
<li>Shortness of breath or difficulty breathing</li>
<li>Chills</li>
<li>Repeated shaking with chills</li>
<li>Muscle pain</li>
<li>Headache</li>
<li>Sore throat</li>
<li>New loss of taste or smell</li>
</p>
		  </div>
        </div>
    </div>

     <div>
        <p>
		<button style="width: 200px;" class="btn btn-primary" type="button" data-toggle="collapse" data-target="#collapse3" aria-expanded="false" aria-controls="collapseExample">
            Medications
          </button>
          <a class="btn btn-primary" data-toggle="collapse" href="#collapse3" role="button" aria-expanded="false" aria-controls="collapseExample">
            See Details
          </a>
          </p>
        <div class="collapse" id="collapse3">
          <div class="card card-body">
         <p>
		<li> Antiviral or Retroviral Medications</li>
		 <li> Breathing Support such as mechanical ventilation</li>
		   <li>Steroids to reduce lung swelling</li>
		  <li> Blood Plasma Transfusions</li>
</p>
          </div>
        </div>
    </div>

<?php include 'footer1.php' ?>
<?php include 'footer2.php' ?>