<?php include 'db.php' ?>
<?php 
$sql = "SELECT * FROM team";
$result = $link->query($sql);
 ?>

<?php include 'header.php' ?>
<?php include 'menu.php' ?>

<button style="text-align: center;" type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Add Support Team Information</button>


<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Support Team</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
<form action="action/a_team.php" method="POST" class="splash-container">
        <div class="card">
            <div class="card-header">
                <h3 class="mb-1" style="text-align: center; color: green;">Add Support Team</h3>
                <p style="text-align: center;">Please enter the information</p>
            </div>
            <div class="card-body">
                <label for="">Enter Support Team Type</label><br>
                <div class="form-group">
                	<select style="width: 305px; height: 45px;" name="team_type" id="">
                		<option value="Hospital" name="team_type">Hospital</option>
                		<option value="Volunteer" name="team_type">Volunteer</option>
                		<option value="First Aid Support" name="team_type">First Aid Support</option>
                		<option value="Security Guards" name="team_type">Security Guards</option>
                	</select>
                </div>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="team_area" placeholder="Enter Work area" autocomplete="off" required>
                </div>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="number" name="team_contact" placeholder="Enter Contact Number" autocomplete="off" required>
                <div class="form-group pt-2">
                    <button type="submit" class="btn btn-primary">Submit</button>&nbsp;<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </form>
    </div>
  </div>
</div>
</div>

</div>


<div class="col-md-4"  >
          <button style="text-align: center;" type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal2">
  Search  Team Information</button><br>


<div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content" style="background-color: lightsalmon ;">
      <div class="modal-header" >
        <h5 class="modal-title" id="exampleModalLabel">Search Information</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
            <form action="a_search_team.php" method="post">
    <div class="card">
        <div class="card-body">
             <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="r_search" placeholder="Enter Team_ID " autocomplete="off" required>
                </div>
            <div class="form-group pt-2">
                    <button type="submit" class="btn btn-primary">Save changes</button>&nbsp;<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </form>
    </div>
  </div>
</div>
</div>
        </div>

 <br><div class="card">
        <div class="card-body">
            <div class="row">
            	<?php 
            	echo "<div class='ta'><table class='table custom-table'>"."<tr>"."<h2>All Team Information</h2>"."</tr>"."</table></div>" ?>
            <?php 
                if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<div class='ta'><table class='table custom-table'>"."<tr>"."<td>". $row["team_type"]."</td>"."<td>". $row["team_area"]."</td>"."<td>". $row["team_contact"]."</td>"."<br>"."</tr>"."</table></div>";
    } 
} else {
    echo "0 results";
}
$link->close();
             ?>
    </div>
        </div>
    

</div>
<?php include 'footer1.php' ?>
<?php include 'footer2.php' ?>