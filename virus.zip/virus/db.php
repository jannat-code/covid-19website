<?php
$link=mysqli_connect('localhost','root','','virus');

if(mysqli_connect_errno($link))
{
        echo 'Failed to connect';
} 
?>