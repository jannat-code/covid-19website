<?php include 'db.php' ?>
<?php 
$sql="SELECT * FROM check_point";
$result = $link->query($sql);
 ?>


<?php include 'header.php' ?>
<?php include 'menu.php' ?>
<div style="height: 400px;">
<button style="text-align: center;" type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Add Check-point</button><br>


<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Covid-19 Check-point System</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
<form action="action/a_check_point.php" method="post" class="splash-container">
        <div class="card">
            <div class="card-header">
                <h3 class="mb-1" style="text-align: center; color: green;">Check-point System</h3>
                <p style="text-align: center;">Please enter the details.</p>
            </div>
            <div class="card-body">
            	<label for="">Enter Area:</label><br>
                <div class="form-group">
                     <select style="width: 305px; height: 45px;" name="area_type" id="">
                		<option value="Airport" name="area_type">Airport</option>
                		<option value="Land port" name="area_type">Land port</option>
                		</select>
				
               <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="Check_point" placeholder="Enter Check-point Name" autocomplete="off" required>
                </div>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="Facilities" placeholder="Enter Checking Facilities" autocomplete="off" required>
                </div>                
                <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="Team_ID" placeholder="Enter Team ID" autocomplete="off" required>
                </div>
				
				 <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="people_detected" placeholder="Number of affected people detected" autocomplete="off" required>
                </div>
                 <div class="form-group pt-2">
                    <button type="submit" class="btn btn-primary">Save changes</button>&nbsp;<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </form>
    </div>
  </div>
</div>
</div>
</div>
<br><div class="card">
        <div class="card-body">
            <div class="row">
            	<?php 
            	echo "<div class='ta'><table class='table custom-table'>"."<tr>"."<h2>Covid-19 Check-point System Information</h2>"."</tr>"."</table></div>" ?>
            <?php 
                if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<div class='ta'><table class='table custom-table'>"."<tr>"
		."<td>".$row["Area_type"]."</td> "
		."<td>". $row["Check_point_name"]."</td>"
		."<td>". $row["Facilities"]."</td>"
		."<td>". $row["Team_ID"]."</td>"
		."<td>". $row["People_detected"]."</td>"."<br>"."</tr>"."</table></div>";
    } 
} else {
    echo "0 results";
}
$link->close();
             ?>
    </div>
        </div>
    </div>


<?php include 'footer1.php' ?>
<?php include 'footer2.php' ?>