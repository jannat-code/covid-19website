<?php include 'db.php' ?>
<?php 
$sql = "SELECT * FROM awareness ";
$result = $link->query($sql);
?>
<?php include 'header.php' ?>
<?php include 'menu.php' ?>
<div>
<form action="action/a_awareness.php" method="POST" class="splash-container">
        <div class="card">
            <div class="card-header">
                <h3 class="mb-1" style="text-align: center; color: green;">Covid-19 Awareness Program</h3>
                <p style="text-align: center;">Please enter the details</p>
            </div>
            <div class="card-body">
			 <div class="form-group">
                    <input class="form-control form-control-lg" type="number" name="p_id" placeholder="Program ID" autocomplete="off" required>
                </div>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="p_name" placeholder="Program Name" autocomplete="off" required>
                </div>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="p_du" required="" placeholder="Duration " autocomplete="off" required>
                </div>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="p_details" required="" placeholder="Program Details" autocomplete="off" required>
                </div>
				 
                
                <div class="form-group pt-2">
                    <button class="btn btn-block btn-primary" type="submit">Submit</button>
                </div>
        </div>
    </form></div>

<div class="card">
<div class="card-body">
<div>
    <h2 style="margin-top: 5px; margin-left: 370px;"> Covid-19 Awareness Program Details</h2>
</div>
<br><div>
            <?php 
                if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<div class='ta'><table class='table custom-table'><tr>"."<td>".$row["Program_ID"]."</td> "."<td>".$row["Program_Name"]."</td> "."<td>". $row["Duration"]."</td>"."<td>". $row["Program_Details"]."</td>"."<br>"."</tr></table></div>";
    } 
} else {
    echo "0 results";
}
$link->close();
             ?>
    </div></div></div>

<?php include 'footer1.php' ?>
<?php include 'footer2.php' ?>