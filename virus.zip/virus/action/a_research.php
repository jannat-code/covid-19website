<?php include 'db.php' ?>
<?php

// create a variable
$RT_ID=$_POST['RT_ID'];
$RT_name=$_POST['RT_name'];
$r_activity=$_POST['r_activity'];
$number=$_POST['number'];
//Execute the query

$sql="INSERT INTO research(Research_Team_ID, Research_Team_Name, Research_Activities, Contact_Number)
 VALUES('$RT_ID', '$RT_name', '$r_activity' , '$number')";
if(!mysqli_query($link,$sql))
    {
        echo 'Not Inserted';
    }
    else
    {
        header("location: ../Research.php");
  exit;
    }
?>