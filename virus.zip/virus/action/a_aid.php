<?php include 'db.php' ?>
<?php

// create a variable
$aid_type=$_POST['aid_type'];
$amount=$_POST['amount'];
$details=$_POST['details'];
$date=$_POST['date'];
$total_aid=$_POST['total_aid'];


//Execute the query

$sql="INSERT INTO aid(Aid_type, Amount, Details, Date, Total_aid)VALUES('$aid_type','$amount','$details','$date', '$total_aid' )";
if(!mysqli_query($link,$sql))
    {
        echo 'Not Inserted';
    }
    else
    {
        header("location: ../aid.php");
  exit;
    }
?>