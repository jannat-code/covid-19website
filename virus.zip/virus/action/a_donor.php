<?php include 'db.php' ?>
<?php

// create a variable
$doname=$_POST['doname'];
$donumber=$_POST['donumber'];
$dogender=$_POST['dogender'];
$dooccupation=$_POST['dooccupation'];
$doemail=$_POST['doemail'];
$doamount=$_POST['doamount'];
$dodate=$_POST['dodate'];
$docountry=$_POST['docountry'];
$doaddress=$_POST['doaddress'];


//Execute the query

$sql="INSERT INTO donor
(DONOR_NAME, DONOR_NUMBER, DONOR_GENDER, DONOR_OCCUPAATAION, DONOR_EMAIL, DONATION_AMOUNT, DONOR_DATE, DONOR_COUNTRY, DONOR_ADDRESS) VALUES
('$doname', '$donumber','$dogender',  '$dooccupation','$doemail', '$doamount', '$dodate', '$docountry', '$doaddress')";
if(!mysqli_query($link,$sql))
    {
        echo 'Not Inserted';
    }
    else
    {
        header("location: ../donor.php");
  exit;
    }
?>