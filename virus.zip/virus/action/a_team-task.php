<?php include 'db.php' ?>
<?php

// create a variable
$team_type=$_POST['team_type'];
$team_task=$_POST['team_task'];

//Execute the query

$sql="INSERT INTO team_task(Team_name, Team_Task) VALUES('$team_type','$team_task')";
if(!mysqli_query($link,$sql))
    {
        echo 'Not Inserted';
    }
    else
    {
        header("location: ../team-task.php");
  exit;
    }
?>