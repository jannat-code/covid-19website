<?php include 'db.php' ?>
<?php

// create a variable
$needs=$_POST['needs'];
$facilities=$_POST['facilities'];
$location=$_POST['location'];
$working_team=$_POST['working_team'];

//Execute the query

$sql="INSERT INTO quarantine(needs, facilities, location, working_team) VALUES('$needs','$facilities','$location','$working_team')";
if(!mysqli_query($link,$sql))
    {
        echo 'Not Inserted';
    }
    else
    {
        header("location: ../Quarantine.php");
  exit;
    }
?>