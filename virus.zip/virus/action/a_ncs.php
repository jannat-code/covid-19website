<?php include 'db.php' ?>
<?php

// create a variable
$c_name=$_POST['c_name'];
$no_affected=$_POST['no_affected'];
$no_death=$_POST['no_death'];
$c_situation=$_POST['c_situation'];

//Execute the query

$sql="INSERT INTO ncs(Country_Name, No_of_affected_people, No_of_Death, Current_Situation)
 VALUES('$c_name','$no_affected','$no_death', '$c_situation')";
if(!mysqli_query($link,$sql))
    {
        echo 'Not Inserted';
    }
    else
    {
        header("location: ../NCS.php");
  exit;
    }
?>