<?php include 'db.php' ?>
<?php 

$name=$_POST['name'];
$email=$_POST['email'];
$team_type=$_POST['team_type'];
$contact=$_POST['contact'];

$sql="INSERT INTO team_member(Member_Name, Email, Team_Type, Contact)
 VALUES('$name','$email','$team_type','$contact')";

if(!mysqli_query($link,$sql))
    {
        echo 'Not Inserted';
    }
    else
    {
        header("location: ../imteam.php");
  exit;
    }
?>













 ?>