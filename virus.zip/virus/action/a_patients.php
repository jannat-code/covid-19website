<?php include 'db.php' ?>
<?php

// create a variable
$name=$_POST['name'];
$fhname=$_POST['fhname'];
$mname=$_POST['mname'];
$bdate=$_POST['bdate'];
$address=$_POST['address'];
$gender=$_POST['gender'];
$married=$_POST['married'];
$bl_group=$_POST['bl_group'];
$symptoms=$_POST['symptoms'];
$Migration=$_POST['Migration'];
$bd_mig=$_POST['bd_mig'];
$qun_mig=$_POST['qun_mig'];

//Execute the query

$sql="INSERT INTO patients_individual(Patients_Name, Father_Name, Mother_Name, Date_of_Birth, Address, Gender, Marital_Status, Blood_Group, Symptoms, Migration, Migration_Date, Qunt_Migration_Date) VALUES('$name', '$fhname', '$mname','$bdate', '$address', '$gender', '$married', '$bl_group',  '$symptoms','$Migration','$bd_mig', '$qun_mig')";
if(!mysqli_query($link,$sql))
    {
        echo 'Not Inserted';
    }
    else
    {
        header("location: ../patients.php");
  exit;
    }
?>