<?php include 'db.php' ?>
<?php

// create a variable
$area_type=$_POST['area_type'];
$Check_point=$_POST['Check_point'];
$Facilities=$_POST['Facilities'];
$Team_ID=$_POST['Team_ID'];
$people_detected=$_POST['people_detected'];
//Execute the query

$sql="INSERT INTO check_point(Area_type, Check_point_name, Facilities, Team_ID, People_detected) VALUES
('$area_type', '$Check_point', '$Facilities', '$Team_ID', '$people_detected')";
if(!mysqli_query($link,$sql))
    {
        echo 'Not Inserted';
    }
    else
    {
        header("location: ../check_point.php");
  exit;
    }
?>