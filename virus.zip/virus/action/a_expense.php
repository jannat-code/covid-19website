<?php include 'db.php' ?>
<?php

// create a variable
$exname=$_POST['exname'];
$examount=$_POST['examount'];
$exdate=$_POST['exdate'];
$exdetails=$_POST['exdetails'];

//Execute the query

$sql="INSERT INTO expense(Expense_Name,Expense_Amount,Expense_Date,Expense_Details) VALUES('$exname','$examount','$exdate','$exdetails')";
if(!mysqli_query($link,$sql))
    {
        echo 'Not Inserted';
    }
    else
    {
        header("location: ../form/expense.php");
  exit;
    }
?>