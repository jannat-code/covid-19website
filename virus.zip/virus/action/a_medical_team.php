<?php include 'db.php' ?>
<?php

// create a variable
$mname=$_POST['mname'];
$pname=$_POST['pname'];
$location=$_POST['location'];
$reports=$_POST['reports'];

//Execute the query

$sql="INSERT INTO medical_team(Team_Name, Treating_Patient_Name, Location, reports ) VALUES('$mname','$pname','$location','$reports')";
if(!mysqli_query($link,$sql))
    {
        echo 'Not Inserted';
    }
    else
    {
        header("location: ../medical_team.php");
  exit;
    }
?>