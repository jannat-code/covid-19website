<?php include 'db.php' ?>
<?php

// create a variable
$PROBLEM=$_POST['PROBLEM'];
$SOLUTION=$_POST['SOLUTION'];

//Execute the query

$sql="INSERT INTO emergency(PROBLEM ,SOLUTION) VALUES('$PROBLEM','$SOLUTION')";
if(!mysqli_query($link,$sql))
    {
        echo 'Not Inserted';
    }
    else
    {
        header("location: ../emergency.php");
  exit;
    }
?>