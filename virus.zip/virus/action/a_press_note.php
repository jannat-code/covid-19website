<?php include 'db.php' ?>
<?php

// create a variable
$pr_ID=$_POST['pr_ID'];
$name=$_POST['name'];
$pr_details=$_POST['pr_details'];

//Execute the query

$sql="INSERT INTO press_note(Press_ID, press_name, Press_Details)
 VALUES('$pr_ID','$name', '$pr_details')";
if(!mysqli_query($link,$sql))
    {
        echo 'Not Inserted';
    }
    else
    {
        header("location: ../Press_Note.php");
  exit;
    }
?>