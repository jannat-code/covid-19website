<?php include 'db.php' ?>
<?php

// create a variable
$p_id=$_POST['p_id'];
$p_name=$_POST['p_name'];
$p_du=$_POST['p_du'];

$p_details=$_POST['p_details'];

//Execute the query

$sql="INSERT INTO awareness(Program_ID, Program_Name, Duration, Program_Details)
 VALUES('$p_id','$p_id','$p_du', '$p_details')";
if(!mysqli_query($link,$sql))
    {
        echo 'Not Inserted';
    }
    else
    {
        header("location: ../Awareness_Program.php");
  exit;
    }
?>