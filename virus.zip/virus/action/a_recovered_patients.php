<?php include 'db.php' ?>
<?php

// create a variable
$Patients_ID=$_POST['Patients_ID'];
$Recovered_date=$_POST['Recovered_date'];
$Comments=$_POST['Comments'];

//Execute the query

$sql="INSERT INTO recovered_patients(Patients_ID, Recovered_Date, Comments) VALUES('$Patients_ID','$Recovered_date','$Comments')";
if(!mysqli_query($link,$sql))
    {
        echo 'Not Inserted';
    }
    else
    {
        header("location: ../recovered_patients.php");
  exit;
    }
?>