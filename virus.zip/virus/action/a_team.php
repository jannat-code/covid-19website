<?php include 'db.php' ?>
<?php

// create a variable
$team_type=$_POST['team_type'];
$team_area=$_POST['team_area'];
$team_contact=$_POST['team_contact'];

//Execute the query

$sql="INSERT INTO team(team_type,team_area,team_contact) VALUES('$team_type','$team_area','$team_contact')";
if(!mysqli_query($link,$sql))
    {
        echo 'Not Inserted';
    }
    else
    {
        header("location: ../team.php");
  exit;
    }
?>