<?php include 'header.php' ?>
<?php include 'menu.php' ?>
<div class="col-md-12">
    <div class="row">
	<div class="col-md-1"></div>
        <div class="col-md-7">
            <button style="text-align: center;" type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Add Patients Individual Information</button><br>


<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background-color: aliceblue ;">
        <h4 class="modal-title" id="exampleModalLabel" style="color:;" >Support Team</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" style="background-color: lightsteelblue ;">
        <form action="action/a_patients.php" method="post" class="splash-container">
		
        <div class="card" >
            <div class="card-header" style="background-color: aquamarine ;">
                <h3 class="mb-1" style="text-align: center; color: green;">Patients Registration</h3>
                
            </div>
            <div class="card-body">
                <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="name" placeholder="Enter Name" autocomplete="off" required>
                </div>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="fhname"  placeholder="Enter Father/Husband’s Name" autocomplete="off" required>
                </div>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="mname" placeholder="Enter Mother’s Name" autocomplete="off" required>
                </div>

                <label for="">Enter Date of Birth</label><br>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="date" name="bdate"autocomplete="off" required>
                </div>
                <div class="form-group">
                    <textarea style="padding: 10px; border-color: #bdd0ef;" placeholder="Enter Address" name="address" id="" cols="38" rows="2" required></textarea>
                </div>
                
                <label for="">Choose Gender:</label><br>                         
                <label class="custom-control custom-radio custom-control-inline">
                    <input value="Male" type="radio" name="gender" checked="" class="custom-control-input"><span class="custom-control-label">Male</span>
                </label>
                <label class="custom-control custom-radio custom-control-inline">
                    <input value="Female" type="radio" name="gender" class="custom-control-input"><span class="custom-control-label">Female</span>
                </label>
                <label class="custom-control custom-radio custom-control-inline">
                    <input value="Other" type="radio" name="gender" class="custom-control-input"><span class="custom-control-label">Other</span>
                </label>
<br>
                <label for="">Choose Marital Status:</label><br>
                                            <label class="custom-control custom-radio custom-control-inline">
                                                <input value="Married" type="radio" name="married" checked="" class="custom-control-input"><span class="custom-control-label">Married</span>
                                            </label>
                                            <label class="custom-control custom-radio custom-control-inline">
                                                <input value="Unmarried" type="radio" name="married" class="custom-control-input"><span class="custom-control-label">Unmarried</span>
                                            </label>
                <div class="form-group">
                    <select style="height: 45px; width: 305px; border: 2px solid gray;" name="bl_group">
                        <option value="" name="bl_group">Select Your Blood Group</option>
                        <option value="A+" name="bl_group">A+</option>
                        <option value="A-" name="bl_group">A-</option>
                        <option value="AB+" name="bl_group">AB+</option>
                        <option value="AB-" name="bl_group">AB-</option>
                        <option value="B+" name="bl_group">B+</option>
                        <option value="B-" name="bl_group">B-</option>
                        <option value="O+" name="bl_group">O+</option>
                        <option value="O-" name="bl_group">O-</option>
                    </select>
                </div>

                <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="symptoms" placeholder="symptoms found" autocomplete="off" required>
                </div>
                
                 <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="Migration" placeholder="Migration country" autocomplete="off" required>
                </div>
               



                <label for="">Migration Date</label><br>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="date" name="bd_mig" autocomplete="off" required>
                </div>
                <label for="">Date of Migration to Quarantine </label><br>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="date" name="qun_mig" autocomplete="off" required>
                </div>
                
				
                <div class="form-group pt-2">
                    <button type="submit" class="btn btn-primary">Save changes</button>&nbsp;<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </form>
    </div>
  </div>
</div>
</div>
 </div>




        <div class="col-md-4">
            <button style="text-align: center;" type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal2">
  Search Individual Patients Information</button><br>


<div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content" style="background-color: lightsalmon ;">
      <div class="modal-header" >
        <h5 class="modal-title" id="exampleModalLabel">Search Information</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
            <form action="a_search_patients.php" method="post">
    <div class="card">
        <div class="card-body">
             <div class="form-group">
                    <input class="form-control form-control-lg" type="number" name="r_search" placeholder="Enter Patients_ID" autocomplete="off" required>
                </div>
            <div class="form-group pt-2">
                    <button type="submit" class="btn btn-primary">Save changes</button>&nbsp;<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </form>
    </div>
  </div>
</div>
</div>
        </div>
        </div>
        </div>
    







<form action="action/a_patients.php" method="post" class="splash-container">
		
        <div class="card" >
            <div class="card-header" style="background-color: aquamarine ;">
                <h3 class="mb-1" style="text-align: center; color: green;">Patients Registration</h3>
                
            </div>
            <div class="card-body">
                <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="name" placeholder="Enter Name" autocomplete="off" required>
                </div>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="fhname"  placeholder="Enter Father/Husband’s Name" autocomplete="off" required>
                </div>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="mname" placeholder="Enter Mother’s Name" autocomplete="off" required>
                </div>

                <label for="">Enter Date of Birth</label><br>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="date" name="bdate"autocomplete="off" required>
                </div>
                <div class="form-group">
                    <textarea style="padding: 10px; border-color: #bdd0ef;" placeholder="Enter Address" name="address" id="" cols="38" rows="2" required></textarea>
                </div>
                
                <label for="">Choose Gender:</label><br>                         
                <label class="custom-control custom-radio custom-control-inline">
                    <input value="Male" type="radio" name="gender" checked="" class="custom-control-input"><span class="custom-control-label">Male</span>
                </label>
                <label class="custom-control custom-radio custom-control-inline">
                    <input value="Female" type="radio" name="gender" class="custom-control-input"><span class="custom-control-label">Female</span>
                </label>
                <label class="custom-control custom-radio custom-control-inline">
                    <input value="Other" type="radio" name="gender" class="custom-control-input"><span class="custom-control-label">Other</span>
                </label>
<br>
                <label for="">Choose Marital Status:</label><br>
                                            <label class="custom-control custom-radio custom-control-inline">
                                                <input value="Married" type="radio" name="married" checked="" class="custom-control-input"><span class="custom-control-label">Married</span>
                                            </label>
                                            <label class="custom-control custom-radio custom-control-inline">
                                                <input value="Unmarried" type="radio" name="married" class="custom-control-input"><span class="custom-control-label">Unmarried</span>
                                            </label>
                <div class="form-group">
                    <select style="height: 45px; width: 305px; border: 2px solid gray;" name="bl_group">
                        <option value="" name="bl_group">Select Your Blood Group</option>
                        <option value="A+" name="bl_group">A+</option>
                        <option value="A-" name="bl_group">A-</option>
                        <option value="AB+" name="bl_group">AB+</option>
                        <option value="AB-" name="bl_group">AB-</option>
                        <option value="B+" name="bl_group">B+</option>
                        <option value="B-" name="bl_group">B-</option>
                        <option value="O+" name="bl_group">O+</option>
                        <option value="O-" name="bl_group">O-</option>
                    </select>
                </div>

                <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="symptoms" placeholder="symptoms found" autocomplete="off" required>
                </div>
                
                 <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="Migration" placeholder="Migration country" autocomplete="off" required>
                </div>
               



                <label for="">Migration Date</label><br>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="date" name="bd_mig" autocomplete="off" required>
                </div>
                <label for="">Date of Migration to Quarantine </label><br>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="date" name="qun_mig" autocomplete="off" required>
                </div>
                
				
                <div class="form-group pt-2">
                    <button type="submit" class="btn btn-primary">Save changes</button>&nbsp;<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </form>
   








    
<?php include 'footer1.php' ?>
<?php include 'footer2.php' ?>